<?php

    /* Cargamos el autocargador que hemos preparado. */
    require_once('autoload.php');

    include ('ejecucion/dir_compress.php');
?>