# DirCompress
Clase para comprimir todo un directorio, con toda su jerarquía, en un zip.

Esta clase permite comprimir todo un directorio en un zip, manteniendo toda la jerarquía de subdirectorios, y colocando todos los archivos en sus correspondientes rutas.

Puedes leer más sobre ella en https://eldesvandejose.com.
